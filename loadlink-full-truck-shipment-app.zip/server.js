// server.js
const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const app = express();
const PORT = 3000;

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Database
const db = new sqlite3.Database('loadlink.db');
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT
  )`);
});

// Signup route
app.post('/signup', async (req, res) => {
  const { email, password } = req.body;
  const hash = await bcrypt.hash(password, 10);
  db.run(`INSERT INTO users (email, password) VALUES (?, ?)`, [email, hash], (err) => {
    if (err) return res.status(500).send('User already exists or error occurred.');
    res.status(200).send('Signup successful');
  });
});

// Login route
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  db.get(`SELECT * FROM users WHERE email = ?`, [email], async (err, user) => {
    if (err || !user) return res.status(400).send('Invalid email or password');
    const valid = await bcrypt.compare(password, user.password);
    if (valid) res.status(200).send('Login successful');
    else res.status(400).send('Invalid email or password');
  });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

// Trucks table
db.run(`CREATE TABLE IF NOT EXISTS trucks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  number TEXT NOT NULL,
  driver TEXT NOT NULL,
  status TEXT NOT NULL,
  user_id INTEGER,
  FOREIGN KEY(user_id) REFERENCES users(id)
);`);

// Middleware to protect routes
function auth(req, res, next) {
  if (!req.session.user) return res.status(401).send('Unauthorized');
  next();
}

// Get all trucks for logged-in user
app.get('/trucks', auth, (req, res) => {
  db.all(`SELECT * FROM trucks WHERE user_id = ?`, [req.session.user.id], (err, rows) => {
    if (err) return res.status(500).send('Failed to fetch trucks');
    res.json(rows);
  });
});

// Add new truck
app.post('/trucks', auth, (req, res) => {
  const { number, driver, status } = req.body;
  db.run(`INSERT INTO trucks (number, driver, status, user_id) VALUES (?, ?, ?, ?)`,
    [number, driver, status, req.session.user.id],
    (err) => {
      if (err) return res.status(500).send('Failed to add truck');
      res.sendStatus(200);
    });
});

// Update truck
app.put('/trucks/:id', auth, (req, res) => {
  const { number, driver, status } = req.body;
  const truckId = req.params.id;
  db.run(`UPDATE trucks SET number = ?, driver = ?, status = ? WHERE id = ? AND user_id = ?`,
    [number, driver, status, truckId, req.session.user.id],
    (err) => {
      if (err) return res.status(500).send('Failed to update truck');
      res.sendStatus(200);
    });
});

// Delete truck
app.delete('/trucks/:id', auth, (req, res) => {
  const truckId = req.params.id;
  db.run(`DELETE FROM trucks WHERE id = ? AND user_id = ?`, [truckId, req.session.user.id], (err) => {
    if (err) return res.status(500).send('Failed to delete truck');
    res.sendStatus(200);
  });
});

// Shipments table
db.run(`CREATE TABLE IF NOT EXISTS shipments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  description TEXT NOT NULL,
  origin TEXT NOT NULL,
  destination TEXT NOT NULL,
  status TEXT NOT NULL,
  truck_id INTEGER,
  user_id INTEGER,
  FOREIGN KEY(truck_id) REFERENCES trucks(id),
  FOREIGN KEY(user_id) REFERENCES users(id)
);`);

// Get all shipments for user
app.get('/shipments', auth, (req, res) => {
  db.all(`SELECT * FROM shipments WHERE user_id = ?`, [req.session.user.id], (err, rows) => {
    if (err) return res.status(500).send('Failed to fetch shipments');
    res.json(rows);
  });
});

// Add a shipment
app.post('/shipments', auth, (req, res) => {
  const { description, origin, destination, status, truck_id } = req.body;
  db.run(`INSERT INTO shipments (description, origin, destination, status, truck_id, user_id)
          VALUES (?, ?, ?, ?, ?, ?)`,
    [description, origin, destination, status, truck_id, req.session.user.id],
    (err) => {
      if (err) return res.status(500).send('Failed to add shipment');
      res.sendStatus(200);
    });
});
