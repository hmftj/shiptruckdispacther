// database.js
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Connect to SQLite database (creates it if it doesn't exist)
const db = new sqlite3.Database(path.join(__dirname, 'loadlink.db'), (err) => {
  if (err) {
    console.error('Database connection error:', err);
  } else {
    console.log('Connected to SQLite database');
  }
});

module.exports = db;
// Initialize tables
db.serialize(() => {
    // Users table
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK (role IN ('shipper', 'carrier', 'admin')),
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
  
    // Loads table
    db.run(`
      CREATE TABLE IF NOT EXISTS loads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        origin TEXT NOT NULL,
        destination TEXT NOT NULL,
        weight REAL NOT NULL,
        typeOfGoods TEXT NOT NULL,
        postedBy INTEGER NOT NULL,
        status TEXT DEFAULT 'available' CHECK (status IN ('available', 'booked', 'completed')),
        createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(postedBy) REFERENCES users(id)
      )
    `);
  
    console.log('Tables initialized');
  });