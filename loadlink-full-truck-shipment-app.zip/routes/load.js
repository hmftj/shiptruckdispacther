const express = require('express');
const router = express.Router();
const db = require('../database');

// Post a load
router.post('/', (req, res) => {
  const { origin, destination, weight, typeOfGoods, postedBy } = req.body;

  db.run(
    `INSERT INTO loads (origin, destination, weight, typeOfGoods, postedBy) VALUES (?, ?, ?, ?, ?)`,
    [origin, destination, weight, typeOfGoods, postedBy],
    function (err) {
      if (err) return res.status(400).json({ message: err.message });
      res.status(201).json({ id: this.lastID });
    }
  );
});

// Get all loads
router.get('/', (req, res) => {
  db.all(
    `SELECT loads.*, users.username as postedByName 
     FROM loads LEFT JOIN users ON loads.postedBy = users.id`,
    [],
    (err, loads) => {
      if (err) return res.status(500).json({ message: err.message });
      res.json(loads);
    }
  );
});

module.exports = router;