// DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  // Check authentication state
  checkAuthState();
  
  // Initialize forms
  initSignupForm();
  initLoginForm();
});

// Auth state management
function checkAuthState() {
  const token = localStorage.getItem('token');
  const currentPath = window.location.pathname;
  
  // Redirect logic
  if (token && (currentPath.endsWith('index.html') || currentPath === '/')) {
    redirectToDashboard();
  } else if (!token && (currentPath.includes('dashboard'))) {
    window.location.href = '/index.html';
  }
}

function redirectToDashboard() {
  const token = localStorage.getItem('token');
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    if (payload.role === 'carrier') {
      window.location.href = '/carrier-dashboard.html';
    } else {
      window.location.href = '/shipper-dashboard.html';
    }
  } catch (e) {
    console.error('Token parsing error:', e);
    localStorage.removeItem('token');
    window.location.href = '/index.html';
  }
}

// Form Handlers
function initSignupForm() {
  const form = document.getElementById('signup-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('signup-email').value.trim();
    const password = document.getElementById('signup-password').value;
    const role = document.getElementById('signup-role').value;
    
    if (!validateEmail(email)) {
      showAlert('Please enter a valid email address', 'error');
      return;
    }
    
    if (password.length < 8) {
      showAlert('Password must be at least 8 characters', 'error');
      return;
    }

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: email.split('@')[0],
          email,
          password,
          role
        }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Registration failed');
      }
      
      showAlert('Registration successful! Please login.', 'success');
      form.reset();
      setTimeout(() => window.location.href = '/index.html#login', 1500);
    } catch (error) {
      showAlert(error.message, 'error');
      console.error('Signup error:', error);
    }
  });
}

function initLoginForm() {
  const form = document.getElementById('login-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    
    if (!validateEmail(email)) {
      showAlert('Please enter a valid email address', 'error');
      return;
    }

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Login failed');
      }
      
      localStorage.setItem('token', data.token);
      showAlert('Login successful!', 'success');
      setTimeout(redirectToDashboard, 1000);
    } catch (error) {
      showAlert(error.message, 'error');
      console.error('Login error:', error);
    }
  });
}

// Helper functions
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function showAlert(message, type = 'info') {
  // Remove existing alerts
  const oldAlert = document.querySelector('.custom-alert');
  if (oldAlert) oldAlert.remove();
  
  // Create alert element
  const alert = document.createElement('div');
  alert.className = `custom-alert ${type}`;
  alert.textContent = message;
  
  // Add to DOM
  document.body.appendChild(alert);
  
  // Auto-remove after 5 seconds
  setTimeout(() => alert.remove(), 5000);
}

// Logout functionality
document.querySelectorAll('[data-logout]').forEach(button => {
  button.addEventListener('click', () => {
    localStorage.removeItem('token');
    window.location.href = '/index.html';
  });
});