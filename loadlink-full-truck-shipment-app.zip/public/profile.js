fetch('/profile')
  .then(res => {
    if (!res.ok) {
      window.location.href = 'login.html';
    }
    return res.json();
  })
  .then(data => {
    document.getElementById('user-info').textContent = `Logged in as: ${data.user.email}`;
  });

document.getElementById('logout-btn').addEventListener('click', async () => {
  await fetch('/logout', { method: 'POST' });
  window.location.href = 'login.html';
});
