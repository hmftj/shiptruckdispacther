function fetchTrucks() {
  fetch('/trucks')
    .then(res => res.json())
    .then(trucks => {
      const list = document.getElementById('truck-list');
      list.innerHTML = '';
      trucks.forEach(truck => {
        const li = document.createElement('li');
        li.innerHTML = `
          <strong>${truck.number}</strong> - ${truck.driver} - ${truck.status}
          <button onclick="deleteTruck(${truck.id})">Delete</button>
          <button onclick="editTruck(${truck.id}, '${truck.number}', '${truck.driver}', '${truck.status}')">Edit</button>
        `;
        list.appendChild(li);
      });
    });
}

function deleteTruck(id) {
  fetch('/trucks/' + id, { method: 'DELETE' })
    .then(() => fetchTrucks());
}

function editTruck(id, number, driver, status) {
  const newNumber = prompt("Truck Number:", number);
  const newDriver = prompt("Driver:", driver);
  const newStatus = prompt("Status:", status);
  if (newNumber && newDriver && newStatus) {
    fetch('/trucks/' + id, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ number: newNumber, driver: newDriver, status: newStatus })
    }).then(() => fetchTrucks());
  }
}

document.getElementById('truck-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const form = e.target;
  const truck = {
    number: form.number.value,
    driver: form.driver.value,
    status: form.status.value
  };
  fetch('/trucks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(truck)
  }).then(() => {
    form.reset();
    fetchTrucks();
  });
});

document.getElementById('shipment-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const form = e.target;
  const shipment = {
    description: form.description.value,
    origin: form.origin.value,
    destination: form.destination.value,
    status: form.status.value,
    truck_id: parseInt(form.truck_id.value) || null
  };
  fetch('/shipments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(shipment)
  }).then(() => {
    form.reset();
    fetchShipments();
  });
});

function fetchShipments() {
  fetch('/shipments')
    .then(res => res.json())
    .then(shipments => {
      const list = document.getElementById('shipment-list');
      list.innerHTML = '';
      shipments.forEach(s => {
        const li = document.createElement('li');
        li.textContent = `${s.description} from ${s.origin} to ${s.destination} - ${s.status} (Truck ID: ${s.truck_id || 'none'})`;
        list.appendChild(li);
      });
    });
}

document.getElementById('logout-btn').addEventListener('click', async () => {
  await fetch('/logout', { method: 'POST' });
  window.location.href = 'login.html';
});

fetchTrucks();
fetchShipments();